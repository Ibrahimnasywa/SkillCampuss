<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Admin Panel — SkillCampus</title>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=DM+Serif+Display:ital@0;1&display=swap" rel="stylesheet" />
  <style>
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    :root {
      --primary: #0059A1;
      --primary-light: #018BD8;
      --primary-pale: #d0e8f7;
      --accent: #42A5F5;
      --dark: #00010E;
      --text: #002D6D;
      --text-muted: #0059A1;
      --bg: #e8f3fb;
      --white: #fff;
      --border: #b8d4ee;
      --radius: 13px;
      --sidebar: 248px;
      --admin: #001954;
    }
    body { font-family: 'Plus Jakarta Sans', sans-serif; background: var(--bg); color: var(--text); display: flex; min-height: 100vh; }

    /* SIDEBAR */
    .sidebar { width: var(--sidebar); background: var(--admin); color: white; display: flex; flex-direction: column; position: fixed; top: 0; left: 0; bottom: 0; z-index: 50; }
    .sidebar-logo { padding: 1.4rem 1.25rem 1rem; border-bottom: 1px solid rgba(255,255,255,0.07); }
    .sidebar-logo .brand { font-size: 1.1rem; font-weight: 800; color: white; }
    .sidebar-logo .brand span { color: #42A5F5; }
    .sidebar-logo .sub { font-size: 0.68rem; color: rgba(255,255,255,0.35); margin-top: 2px; display: flex; align-items: center; gap: 5px; }
    .sidebar-logo .sub::before { content: ''; width: 6px; height: 6px; background: #42A5F5; border-radius: 50%; }

    .admin-profile { padding: 0.9rem 1.25rem; display: flex; align-items: center; gap: 9px; border-bottom: 1px solid rgba(255,255,255,0.07); }
    .admin-avatar { width: 36px; height: 36px; border-radius: 9px; background: #0072BC; display: flex; align-items: center; justify-content: center; font-size: 1rem; flex-shrink: 0; }
    .admin-info .name { font-size: 0.82rem; font-weight: 700; }
    .admin-info .role { font-size: 0.68rem; color: rgba(255,255,255,0.45); }
    .admin-badge { margin-left: auto; font-size: 0.6rem; font-weight: 700; background: #0072BC; color: white; padding: 2px 7px; border-radius: 50px; }

    .sidebar-nav { flex: 1; padding: 0.75rem 0; overflow-y: auto; }
    .nav-section { padding: 0.5rem 1.25rem; font-size: 0.62rem; font-weight: 700; letter-spacing: 0.1em; text-transform: uppercase; color: rgba(255,255,255,0.28); margin-top: 0.4rem; }
    .nav-item { display: flex; align-items: center; gap: 9px; padding: 8px 1.25rem; font-size: 0.83rem; font-weight: 500; color: rgba(255,255,255,0.6); cursor: pointer; transition: all 0.15s; border-left: 3px solid transparent; text-decoration: none; }
    .nav-item:hover { color: white; background: rgba(255,255,255,0.05); }
    .nav-item.active { color: white; background: rgba(1,139,216,0.18); border-left-color: #018BD8; }
    .nav-item .icon { width: 18px; text-align: center; font-size: 0.95rem; }
    .nav-item .nbadge { margin-left: auto; font-size: 0.63rem; font-weight: 700; background: #0072BC; color: white; padding: 1px 6px; border-radius: 50px; }

    .sidebar-footer { padding: 1rem 1.25rem; border-top: 1px solid rgba(255,255,255,0.07); }
    .sidebar-footer a { font-size: 0.8rem; color: rgba(255,255,255,0.45); text-decoration: none; display: flex; align-items: center; gap: 7px; transition: color 0.15s; }
    .sidebar-footer a:hover { color: white; }

    /* MAIN */
    .main { margin-left: var(--sidebar); flex: 1; display: flex; flex-direction: column; min-width: 0; }

    /* TOPBAR */
    .topbar { background: white; border-bottom: 1px solid var(--border); display: flex; align-items: center; justify-content: space-between; padding: 0 1.75rem; height: 58px; position: sticky; top: 0; z-index: 40; }
    .topbar-left h1 { font-size: 1rem; font-weight: 700; color: var(--dark); }
    .topbar-left p { font-size: 0.75rem; color: var(--text-muted); }
    .topbar-right { display: flex; align-items: center; gap: 10px; }
    .topbar-btn { width: 34px; height: 34px; border-radius: 8px; border: 1px solid var(--border); background: white; cursor: pointer; display: flex; align-items: center; justify-content: center; font-size: 0.95rem; position: relative; }
    .notif-dot { position: absolute; top: 5px; right: 5px; width: 6px; height: 6px; background: #0072BC; border-radius: 50%; border: 1.5px solid white; }
    .search-bar { display: flex; align-items: center; gap: 7px; background: var(--bg); border: 1px solid var(--border); border-radius: 8px; padding: 0 12px; height: 34px; }
    .search-bar input { border: none; background: transparent; font-size: 0.82rem; font-family: inherit; outline: none; width: 180px; }

    /* CONTENT */
    .content { padding: 1.5rem; flex: 1; }
    .panel { display: none; }
    .panel.active { display: block; }

    /* STATS */
    .stats-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 1rem; margin-bottom: 1.25rem; }
    .stat-card { background: white; border-radius: var(--radius); padding: 1.1rem; border: 1px solid var(--border); }
    .stat-top { display: flex; align-items: flex-start; justify-content: space-between; margin-bottom: 10px; }
    .stat-icon { width: 38px; height: 38px; border-radius: 9px; display: flex; align-items: center; justify-content: center; font-size: 1.1rem; }
    .stat-trend { font-size: 0.68rem; font-weight: 700; padding: 2px 7px; border-radius: 50px; }
    .trend-up { background: #d0e8f7; color: #0059A1; }
    .trend-dn { background: #dde8f5; color: #002D6D; }
    .stat-val { font-size: 1.55rem; font-weight: 800; color: var(--dark); margin-bottom: 2px; }
    .stat-lbl { font-size: 0.74rem; color: var(--text-muted); }

    /* CARD */
    .card { background: white; border-radius: var(--radius); border: 1px solid var(--border); padding: 1.15rem; }
    .card-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 1rem; }
    .card-header h3 { font-size: 0.88rem; font-weight: 700; color: var(--dark); }
    .card-header a { font-size: 0.75rem; color: var(--primary); font-weight: 600; text-decoration: none; }
    .two-col { display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; margin-bottom: 1rem; }
    .three-two { display: grid; grid-template-columns: 3fr 2fr; gap: 1rem; margin-bottom: 1rem; }

    /* TABLE */
    .data-table { width: 100%; border-collapse: collapse; }
    .data-table th { font-size: 0.69rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em; color: var(--text-muted); text-align: left; padding: 7px 10px; border-bottom: 1px solid var(--border); white-space: nowrap; }
    .data-table td { font-size: 0.81rem; padding: 9px 10px; border-bottom: 1px solid var(--border); vertical-align: middle; }
    .data-table tr:last-child td { border-bottom: none; }
    .data-table tr:hover td { background: var(--bg); }

    .badge { font-size: 0.67rem; font-weight: 700; padding: 2px 8px; border-radius: 50px; }
    .badge-aktif { background: #d0e8f7; color: #0059A1; }
    .badge-nonaktif { background: #c8d8ee; color: #002D6D; }
    .badge-pending { background: #ddeaf7; color: #004286; }
    .badge-penyedia { background: #e0f0fb; color: #0072BC; }
    .badge-pencari { background: #c8dcf5; color: #004286; }
    .badge-admin { background: #b8cce8; color: #001954; }
    .badge-selesai { background: #d0e8f7; color: #0059A1; }
    .badge-proses { background: #ddeaf7; color: #004286; }
    .badge-batal { background: #ccd8eb; color: #002D6D; }

    .tbl-btn { font-size: 0.7rem; font-weight: 600; padding: 4px 10px; border-radius: 6px; border: 1px solid var(--border); background: white; cursor: pointer; font-family: inherit; transition: all 0.15s; }
    .tbl-btn:hover { border-color: var(--primary); color: var(--primary); }
    .tbl-btn.danger { color: #002D6D; }
    .tbl-btn.danger:hover { background: #dde8f5; border-color: #002D6D; }
    .tbl-btn.success { background: #0059A1; color: white; border-color: #0059A1; }
    .tbl-btn.success:hover { background: #018BD8; border-color: #018BD8; }

    /* USER AVATAR IN TABLE */
    .user-cell { display: flex; align-items: center; gap: 8px; }
    .user-cell .av { width: 28px; height: 28px; border-radius: 50%; background: #d0e8f7; display: flex; align-items: center; justify-content: center; font-size: 0.85rem; flex-shrink: 0; }
    .user-cell .un { font-weight: 600; font-size: 0.81rem; }
    .user-cell .ue { font-size: 0.71rem; color: var(--text-muted); }

    /* BAR CHART */
    .bar-chart { display: flex; align-items: flex-end; gap: 6px; height: 90px; padding-top: 6px; }
    .bar-wrap { flex: 1; display: flex; flex-direction: column; align-items: center; gap: 4px; }
    .bar { width: 100%; border-radius: 5px 5px 0 0; background: #c8dcf5; transition: background 0.2s; cursor: pointer; }
    .bar:hover, .bar.hi { background: #0059A1; }
    .bar-lbl { font-size: 0.6rem; color: var(--text-muted); }

    /* DONUT CHART (CSS) */
    .donut-wrap { display: flex; align-items: center; gap: 1rem; }
    .donut { width: 80px; height: 80px; border-radius: 50%; background: conic-gradient(#001954 0% 38%, #0059A1 38% 65%, #018BD8 65% 80%, #42A5F5 80% 93%, #b8d4ee 93% 100%); position: relative; flex-shrink: 0; }
    .donut::after { content: ''; position: absolute; inset: 18px; background: white; border-radius: 50%; }
    .donut-legend { display: flex; flex-direction: column; gap: 5px; }
    .legend-item { display: flex; align-items: center; gap: 6px; font-size: 0.72rem; color: var(--text-muted); }
    .legend-dot { width: 8px; height: 8px; border-radius: 50%; flex-shrink: 0; }

    /* ACTIVITY */
    .feed-item { display: flex; align-items: flex-start; gap: 9px; padding: 8px 0; border-bottom: 1px solid var(--border); }
    .feed-item:last-child { border-bottom: none; }
    .feed-icon { width: 30px; height: 30px; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-size: 0.9rem; flex-shrink: 0; }
    .feed-text { flex: 1; font-size: 0.79rem; color: var(--text-muted); line-height: 1.4; }
    .feed-text strong { color: var(--dark); }
    .feed-time { font-size: 0.67rem; color: var(--text-muted); white-space: nowrap; }

    /* SEARCH + FILTER BAR */
    .toolbar { display: flex; align-items: center; gap: 10px; margin-bottom: 1rem; flex-wrap: wrap; }
    .toolbar input[type="text"] { padding: 7px 12px; border: 1.5px solid var(--border); border-radius: 8px; font-size: 0.82rem; font-family: inherit; outline: none; transition: border-color 0.2s; }
    .toolbar input:focus { border-color: var(--primary); }
    .toolbar select { padding: 7px 12px; border: 1.5px solid var(--border); border-radius: 8px; font-size: 0.82rem; font-family: inherit; outline: none; background: white; cursor: pointer; }
    .result-count { font-size: 0.8rem; color: var(--text-muted); margin-left: auto; }

    /* FORM */
    .setting-section { margin-bottom: 1.25rem; }
    .setting-section h4 { font-size: 0.85rem; font-weight: 700; color: var(--dark); margin-bottom: 0.75rem; padding-bottom: 8px; border-bottom: 1px solid var(--border); }
    .setting-row { display: flex; align-items: center; justify-content: space-between; padding: 10px 0; border-bottom: 1px solid var(--border); }
    .setting-row:last-child { border-bottom: none; }
    .setting-info .title { font-size: 0.85rem; font-weight: 600; color: var(--dark); }
    .setting-info .desc { font-size: 0.76rem; color: var(--text-muted); margin-top: 2px; }
    .toggle { width: 40px; height: 22px; background: var(--border); border-radius: 50px; position: relative; cursor: pointer; transition: background 0.2s; flex-shrink: 0; }
    .toggle.on { background: #0059A1; }
    .toggle::after { content: ''; position: absolute; width: 16px; height: 16px; background: white; border-radius: 50%; top: 3px; left: 3px; transition: left 0.2s; box-shadow: 0 1px 3px rgba(0,0,0,0.2); }
    .toggle.on::after { left: 21px; }

    /* TOAST */
    .toast { position: fixed; bottom: 1.5rem; right: 1.5rem; background: #001954; color: white; padding: 11px 18px; border-radius: 10px; font-size: 0.83rem; font-weight: 600; box-shadow: 0 8px 24px rgba(0,25,84,0.3); z-index: 999; display: none; align-items: center; gap: 8px; }
    .toast.show { display: flex; }

    /* MODAL */
    .modal-overlay { display: none; position: fixed; inset: 0; background: rgba(0,2,37,0.5); z-index: 200; align-items: center; justify-content: center; padding: 1rem; }
    .modal-overlay.show { display: flex; }
    .modal-box { background: white; border-radius: 16px; padding: 1.5rem; max-width: 460px; width: 100%; animation: su 0.2s ease; }
    @keyframes su { from { transform: translateY(16px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
    .modal-box h3 { font-size: 1.05rem; font-weight: 800; margin-bottom: 1rem; color: var(--dark); }
    .modal-box p { font-size: 0.85rem; color: var(--text-muted); margin-bottom: 1.25rem; line-height: 1.6; }
    .modal-btns { display: flex; gap: 8px; justify-content: flex-end; }
    .btn-confirm { padding: 8px 20px; background: #004286; color: white; border: none; border-radius: 8px; font-size: 0.85rem; font-weight: 700; cursor: pointer; font-family: inherit; }
    .btn-cancel { padding: 8px 20px; border: 1.5px solid var(--border); background: white; border-radius: 8px; font-size: 0.85rem; font-weight: 600; cursor: pointer; font-family: inherit; }
    .btn-green { padding: 8px 20px; background: #0059A1; color: white; border: none; border-radius: 8px; font-size: 0.85rem; font-weight: 700; cursor: pointer; font-family: inherit; }

    @media (max-width: 900px) {
      .sidebar { display: none; }
      .main { margin-left: 0; }
      .stats-grid { grid-template-columns: 1fr 1fr; }
      .two-col, .three-two { grid-template-columns: 1fr; }
    }
  </style>
</head>
<body>

<!-- SIDEBAR -->
<aside class="sidebar">
  <div class="sidebar-logo">
    <div class="brand">Skill<span>Campus</span></div>
    <div class="sub">Admin Panel · Sistem Aktif</div>
  </div>
  <div class="admin-profile">
    <div class="admin-avatar">🛡️</div>
    <div class="admin-info">
      <div class="name">Administrator</div>
      <div class="role">Super Admin</div>
    </div>
    <div class="admin-badge">ADMIN</div>
  </div>
  <nav class="sidebar-nav">
    <div class="nav-section">Dashboard</div>
    <a class="nav-item active" onclick="showPanel('overview', this)"><span class="icon">📊</span> Overview</a>
    <div class="nav-section">Manajemen</div>
    <a class="nav-item" onclick="showPanel('users', this)"><span class="icon">👥</span> Kelola Pengguna <span class="nbadge">2</span></a>
    <a class="nav-item" onclick="showPanel('jasa', this)"><span class="icon">💼</span> Kelola Jasa <span class="nbadge">3</span></a>
    <a class="nav-item" onclick="showPanel('transaksi', this)"><span class="icon">💳</span> Transaksi</a>
    <a class="nav-item" onclick="showPanel('laporan', this)"><span class="icon">📈</span> Laporan</a>
    <div class="nav-section">Sistem</div>
    <a class="nav-item" onclick="showPanel('pengaturan', this)"><span class="icon">⚙️</span> Pengaturan</a>
  </nav>
  <div class="sidebar-footer">
    <a href="dashboard.php">🚪 Keluar dari Admin</a>
  </div>
</aside>

<!-- MAIN -->
<div class="main">
  <header class="topbar">
    <div class="topbar-left">
      <h1 id="topbarTitle">Admin Overview</h1>
      <p id="topbarSub">Ringkasan aktivitas platform SkillCampus</p>
    </div>
    <div class="topbar-right">
      <div class="search-bar">
        <span>🔍</span>
        <input type="text" placeholder="Cari di panel..." />
      </div>
      <button class="topbar-btn">🔔 <span class="notif-dot"></span></button>
      <button class="topbar-btn">🛡️</button>
    </div>
  </header>

  <div class="content">

    <!-- ═══ OVERVIEW ═══ -->
    <div class="panel active" id="panel-overview">
      <div class="stats-grid">
        <div class="stat-card">
          <div class="stat-top"><div class="stat-icon" style="background:#d0e8f7;">👥</div><span class="stat-trend trend-up">↑ 12%</span></div>
          <div class="stat-val">248</div><div class="stat-lbl">Total Pengguna</div>
        </div>
        <div class="stat-card">
          <div class="stat-top"><div class="stat-icon" style="background:#c8dcf5;">💼</div><span class="stat-trend trend-up">↑ 8%</span></div>
          <div class="stat-val">183</div><div class="stat-lbl">Jasa Terdaftar</div>
        </div>
        <div class="stat-card">
          <div class="stat-top"><div class="stat-icon" style="background:#ddeaf7;">💳</div><span class="stat-trend trend-up">↑ 23%</span></div>
          <div class="stat-val">1.247</div><div class="stat-lbl">Total Transaksi</div>
        </div>
        <div class="stat-card">
          <div class="stat-top"><div class="stat-icon" style="background:#b8cce8;">💰</div><span class="stat-trend trend-up">↑ 31%</span></div>
          <div class="stat-val">Rp 48Jt</div><div class="stat-lbl">Volume Transaksi</div>
        </div>
      </div>

      <div class="three-two">
        <div class="card">
          <div class="card-header"><h3>📈 Transaksi 7 Hari Terakhir</h3><span style="font-size:0.75rem; color:var(--text-muted);">Januari 2025</span></div>
          <div class="bar-chart">
            <div class="bar-wrap"><div class="bar" style="height:45%;"></div><div class="bar-lbl">Sen</div></div>
            <div class="bar-wrap"><div class="bar" style="height:62%;"></div><div class="bar-lbl">Sel</div></div>
            <div class="bar-wrap"><div class="bar" style="height:38%;"></div><div class="bar-lbl">Rab</div></div>
            <div class="bar-wrap"><div class="bar" style="height:78%;"></div><div class="bar-lbl">Kam</div></div>
            <div class="bar-wrap"><div class="bar hi" style="height:100%;"></div><div class="bar-lbl">Jum</div></div>
            <div class="bar-wrap"><div class="bar" style="height:55%;"></div><div class="bar-lbl">Sab</div></div>
            <div class="bar-wrap"><div class="bar" style="height:68%;"></div><div class="bar-lbl">Min</div></div>
          </div>
          <div style="margin-top:10px; display:flex; justify-content:space-between; font-size:0.73rem; color:var(--text-muted);">
            <span>Total: <strong style="color:var(--dark)">Rp 12.400.000</strong></span>
            <span style="color:#0059A1; font-weight:700;">↑ 23% vs minggu lalu</span>
          </div>
        </div>

        <div class="card">
          <div class="card-header"><h3>📊 Jasa per Kategori</h3></div>
          <div class="donut-wrap">
            <div class="donut"></div>
            <div class="donut-legend">
              <div class="legend-item"><div class="legend-dot" style="background:#001954;"></div>Bimbel (38%)</div>
              <div class="legend-item"><div class="legend-dot" style="background:#0059A1;"></div>Desain (27%)</div>
              <div class="legend-item"><div class="legend-dot" style="background:#018BD8;"></div>Video (15%)</div>
              <div class="legend-item"><div class="legend-dot" style="background:#42A5F5;"></div>Website (13%)</div>
              <div class="legend-item"><div class="legend-dot" style="background:#b8d4ee;"></div>Lainnya (7%)</div>
            </div>
          </div>
        </div>
      </div>

      <div class="two-col">
        <div class="card">
          <div class="card-header"><h3>👥 Pengguna Terbaru</h3><a href="#" onclick="showPanel('users', null)">Lihat Semua →</a></div>
          <table class="data-table">
            <thead><tr><th>Pengguna</th><th>Peran</th><th>Status</th></tr></thead>
            <tbody>
              <tr><td><div class="user-cell"><div class="av">👩</div><div><div class="un">Aulia R.</div><div class="ue">aulia@email.com</div></div></div></td><td><span class="badge badge-penyedia">Penyedia</span></td><td><span class="badge badge-aktif">Aktif</span></td></tr>
              <tr><td><div class="user-cell"><div class="av">🧑</div><div><div class="un">Ibrahim N.</div><div class="ue">ibrahim@email.com</div></div></div></td><td><span class="badge badge-penyedia">Penyedia</span></td><td><span class="badge badge-aktif">Aktif</span></td></tr>
              <tr><td><div class="user-cell"><div class="av">👦</div><div><div class="un">Budi S.</div><div class="ue">budi@email.com</div></div></div></td><td><span class="badge badge-pencari">Pencari</span></td><td><span class="badge badge-aktif">Aktif</span></td></tr>
              <tr><td><div class="user-cell"><div class="av">👩</div><div><div class="un">Rina W.</div><div class="ue">rina@email.com</div></div></div></td><td><span class="badge badge-pencari">Pencari</span></td><td><span class="badge badge-pending">Pending</span></td></tr>
            </tbody>
          </table>
        </div>

        <div class="card">
          <div class="card-header"><h3>🕐 Log Aktivitas</h3></div>
          <div class="feed-item"><div class="feed-icon" style="background:#d0e8f7;">👤</div><div class="feed-text">Pengguna baru <strong>Rina W.</strong> mendaftar sebagai pencari jasa.</div><div class="feed-time">5 mnt</div></div>
          <div class="feed-item"><div class="feed-icon" style="background:#c8dcf5;">💼</div><div class="feed-text">Jasa baru <strong>"Editing Video Cinematic"</strong> menunggu verifikasi.</div><div class="feed-time">22 mnt</div></div>
          <div class="feed-item"><div class="feed-icon" style="background:#ddeaf7;">💳</div><div class="feed-text">Transaksi <strong>#SC-091</strong> senilai Rp 50.000 berhasil.</div><div class="feed-time">1 jam</div></div>
          <div class="feed-item"><div class="feed-icon" style="background:#b8cce8;">⭐</div><div class="feed-text">Laporan ulasan negatif dari pesanan <strong>#SC-088</strong>.</div><div class="feed-time">3 jam</div></div>
          <div class="feed-item"><div class="feed-icon" style="background:#c8d8ee;">🚫</div><div class="feed-text">Akun <strong>user_spam_01</strong> dinonaktifkan secara otomatis.</div><div class="feed-time">Kemarin</div></div>
        </div>
      </div>
    </div>

    <!-- ═══ KELOLA PENGGUNA ═══ -->
    <div class="panel" id="panel-users">
      <div class="toolbar">
        <input type="text" placeholder="🔍 Cari nama atau email..." oninput="searchTable(this, 'userTable')" style="width:220px;" />
        <select onchange="filterTable(this, 'userTable', 4)">
          <option value="">Semua Peran</option>
          <option value="Penyedia">Penyedia</option>
          <option value="Pencari">Pencari</option>
          <option value="Admin">Admin</option>
        </select>
        <select onchange="filterTable(this, 'userTable', 5)">
          <option value="">Semua Status</option>
          <option value="Aktif">Aktif</option>
          <option value="Nonaktif">Nonaktif</option>
          <option value="Pending">Pending</option>
        </select>
        <span class="result-count" id="userCount">8 pengguna</span>
      </div>
      <div class="card">
        <table class="data-table" id="userTable">
          <thead><tr><th>#</th><th>Pengguna</th><th>NIM</th><th>Prodi</th><th>Peran</th><th>Status</th><th>Bergabung</th><th>Aksi</th></tr></thead>
          <tbody>
            <tr><td>1</td><td><div class="user-cell"><div class="av">👩</div><div><div class="un">Aulia Ramadhani S.</div><div class="ue">aulia@email.com</div></div></div></td><td>2409010314</td><td>Sistem Informasi</td><td><span class="badge badge-penyedia">Penyedia</span></td><td><span class="badge badge-aktif">Aktif</span></td><td>1 Jan 2025</td><td><button class="tbl-btn" onclick="showToast('👁️ Detail pengguna')">Detail</button> <button class="tbl-btn danger" onclick="confirmSuspend(this)">Suspend</button></td></tr>
            <tr><td>2</td><td><div class="user-cell"><div class="av">🧑</div><div><div class="un">Ibrahim Nasywa</div><div class="ue">ibrahim@email.com</div></div></div></td><td>2409010328</td><td>Teknik Informatika</td><td><span class="badge badge-penyedia">Penyedia</span></td><td><span class="badge badge-aktif">Aktif</span></td><td>2 Jan 2025</td><td><button class="tbl-btn" onclick="showToast('👁️ Detail pengguna')">Detail</button> <button class="tbl-btn danger" onclick="confirmSuspend(this)">Suspend</button></td></tr>
            <tr><td>3</td><td><div class="user-cell"><div class="av">👨</div><div><div class="un">M. Fajar Rifaldi</div><div class="ue">fajar@email.com</div></div></div></td><td>2409010323</td><td>Teknik Informatika</td><td><span class="badge badge-penyedia">Penyedia</span></td><td><span class="badge badge-aktif">Aktif</span></td><td>3 Jan 2025</td><td><button class="tbl-btn" onclick="showToast('👁️ Detail pengguna')">Detail</button> <button class="tbl-btn danger" onclick="confirmSuspend(this)">Suspend</button></td></tr>
            <tr><td>4</td><td><div class="user-cell"><div class="av">👩</div><div><div class="un">Marini Manda S.</div><div class="ue">marini@email.com</div></div></div></td><td>2409010327</td><td>DKV</td><td><span class="badge badge-penyedia">Penyedia</span></td><td><span class="badge badge-aktif">Aktif</span></td><td>3 Jan 2025</td><td><button class="tbl-btn" onclick="showToast('👁️ Detail pengguna')">Detail</button> <button class="tbl-btn danger" onclick="confirmSuspend(this)">Suspend</button></td></tr>
            <tr><td>5</td><td><div class="user-cell"><div class="av">👦</div><div><div class="un">Aidil Daffa</div><div class="ue">aidil@email.com</div></div></div></td><td>2409010337</td><td>Ilmu Komunikasi</td><td><span class="badge badge-penyedia">Penyedia</span></td><td><span class="badge badge-aktif">Aktif</span></td><td>4 Jan 2025</td><td><button class="tbl-btn" onclick="showToast('👁️ Detail pengguna')">Detail</button> <button class="tbl-btn danger" onclick="confirmSuspend(this)">Suspend</button></td></tr>
            <tr><td>6</td><td><div class="user-cell"><div class="av">👦</div><div><div class="un">Budi Santoso</div><div class="ue">budi@email.com</div></div></div></td><td>—</td><td>—</td><td><span class="badge badge-pencari">Pencari</span></td><td><span class="badge badge-aktif">Aktif</span></td><td>10 Jan 2025</td><td><button class="tbl-btn" onclick="showToast('👁️ Detail pengguna')">Detail</button> <button class="tbl-btn danger" onclick="confirmSuspend(this)">Suspend</button></td></tr>
            <tr><td>7</td><td><div class="user-cell"><div class="av">👩</div><div><div class="un">Rina Wulandari</div><div class="ue">rina@email.com</div></div></div></td><td>—</td><td>—</td><td><span class="badge badge-pencari">Pencari</span></td><td><span class="badge badge-pending">Pending</span></td><td>24 Jan 2025</td><td><button class="tbl-btn success" onclick="activateUser(this)">Aktifkan</button> <button class="tbl-btn danger" onclick="confirmSuspend(this)">Tolak</button></td></tr>
            <tr><td>8</td><td><div class="user-cell"><div class="av">🛡️</div><div><div class="un">Administrator</div><div class="ue">admin@skillcampus.id</div></div></div></td><td>—</td><td>—</td><td><span class="badge badge-admin">Admin</span></td><td><span class="badge badge-aktif">Aktif</span></td><td>1 Jan 2025</td><td>—</td></tr>
          </tbody>
        </table>
      </div>
    </div>

    <!-- ═══ KELOLA JASA ═══ -->
    <div class="panel" id="panel-jasa">
      <div class="toolbar">
        <input type="text" placeholder="🔍 Cari nama jasa..." oninput="searchTable(this, 'jasaTable')" style="width:220px;" />
        <select onchange="filterTable(this, 'jasaTable', 2)">
          <option value="">Semua Kategori</option>
          <option value="Desain">Desain</option>
          <option value="Website">Website</option>
          <option value="Video">Video</option>
          <option value="Bimbel">Bimbel</option>
          <option value="Pengetikan">Pengetikan</option>
          <option value="Fotografi">Fotografi</option>
        </select>
        <select onchange="filterTable(this, 'jasaTable', 5)">
          <option value="">Semua Status</option>
          <option value="Aktif">Aktif</option>
          <option value="Pending">Pending</option>
          <option value="Nonaktif">Nonaktif</option>
        </select>
      </div>
      <div class="card">
        <table class="data-table" id="jasaTable">
          <thead><tr><th>#</th><th>Nama Jasa</th><th>Kategori</th><th>Penyedia</th><th>Harga</th><th>Status</th><th>Pesanan</th><th>Aksi</th></tr></thead>
          <tbody>
            <tr><td>1</td><td>Presentasi PPT Profesional</td><td>Pengetikan</td><td>Aulia R.</td><td>Rp 50.000</td><td><span class="badge badge-aktif">Aktif</span></td><td>87</td><td><button class="tbl-btn" onclick="showToast('👁️ Detail jasa')">Detail</button> <button class="tbl-btn danger" onclick="removeJasa(this)">Hapus</button></td></tr>
            <tr><td>2</td><td>Desain Poster & Flyer</td><td>Desain</td><td>Marini M.</td><td>Rp 75.000</td><td><span class="badge badge-aktif">Aktif</span></td><td>48</td><td><button class="tbl-btn" onclick="showToast('👁️ Detail jasa')">Detail</button> <button class="tbl-btn danger" onclick="removeJasa(this)">Hapus</button></td></tr>
            <tr><td>3</td><td>Editing Reels & TikTok</td><td>Video</td><td>Aidil D.</td><td>Rp 100.000</td><td><span class="badge badge-aktif">Aktif</span></td><td>63</td><td><button class="tbl-btn" onclick="showToast('👁️ Detail jasa')">Detail</button> <button class="tbl-btn danger" onclick="removeJasa(this)">Hapus</button></td></tr>
            <tr><td>4</td><td>Bimbingan Coding Python</td><td>Bimbel</td><td>Ibrahim N.</td><td>Rp 80.000</td><td><span class="badge badge-aktif">Aktif</span></td><td>52</td><td><button class="tbl-btn" onclick="showToast('👁️ Detail jasa')">Detail</button> <button class="tbl-btn danger" onclick="removeJasa(this)">Hapus</button></td></tr>
            <tr><td>5</td><td>Website Company Profile</td><td>Website</td><td>Fajar R.</td><td>Rp 350.000</td><td><span class="badge badge-aktif">Aktif</span></td><td>29</td><td><button class="tbl-btn" onclick="showToast('👁️ Detail jasa')">Detail</button> <button class="tbl-btn danger" onclick="removeJasa(this)">Hapus</button></td></tr>
            <tr><td>6</td><td>Video Cinematic Wedding</td><td>Video</td><td>Aidil D.</td><td>Rp 250.000</td><td><span class="badge badge-pending">Pending</span></td><td>0</td><td><button class="tbl-btn success" onclick="approveJasa(this)">Setujui</button> <button class="tbl-btn danger" onclick="removeJasa(this)">Tolak</button></td></tr>
            <tr><td>7</td><td>Landing Page Event</td><td>Website</td><td>Ibrahim N.</td><td>Rp 150.000</td><td><span class="badge badge-pending">Pending</span></td><td>0</td><td><button class="tbl-btn success" onclick="approveJasa(this)">Setujui</button> <button class="tbl-btn danger" onclick="removeJasa(this)">Tolak</button></td></tr>
            <tr><td>8</td><td>Logo Bisnis & Branding</td><td>Desain</td><td>Fajar R.</td><td>Rp 120.000</td><td><span class="badge badge-pending">Pending</span></td><td>0</td><td><button class="tbl-btn success" onclick="approveJasa(this)">Setujui</button> <button class="tbl-btn danger" onclick="removeJasa(this)">Tolak</button></td></tr>
          </tbody>
        </table>
      </div>
    </div>

    <!-- ═══ TRANSAKSI ═══ -->
    <div class="panel" id="panel-transaksi">
      <div class="toolbar">
        <input type="text" placeholder="🔍 Cari ID atau nama..." oninput="searchTable(this, 'transaksiTable')" style="width:220px;"/>
        <select onchange="filterTable(this, 'transaksiTable', 4)">
          <option value="">Semua Status</option>
          <option value="Selesai">Selesai</option>
          <option value="Diproses">Diproses</option>
          <option value="Dibatalkan">Dibatalkan</option>
        </select>
      </div>
      <div class="card">
        <table class="data-table" id="transaksiTable">
          <thead><tr><th>ID</th><th>Pemesan</th><th>Penyedia</th><th>Jasa</th><th>Status</th><th>Jumlah</th><th>Tanggal</th></tr></thead>
          <tbody>
            <tr><td><strong>#SC-091</strong></td><td>Budi S.</td><td>Aulia R.</td><td>Presentasi PPT</td><td><span class="badge badge-proses">Diproses</span></td><td>Rp 50.000</td><td>24 Jan 2025</td></tr>
            <tr><td><strong>#SC-090</strong></td><td>Rina W.</td><td>Marini M.</td><td>Desain Poster</td><td><span class="badge badge-proses">Diproses</span></td><td>Rp 75.000</td><td>23 Jan 2025</td></tr>
            <tr><td><strong>#SC-089</strong></td><td>Dani K.</td><td>Fajar R.</td><td>Desain Logo</td><td><span class="badge badge-proses">Diproses</span></td><td>Rp 120.000</td><td>22 Jan 2025</td></tr>
            <tr><td><strong>#SC-088</strong></td><td>Siti A.</td><td>Marini M.</td><td>Foto Produk</td><td><span class="badge badge-selesai">Selesai</span></td><td>Rp 200.000</td><td>20 Jan 2025</td></tr>
            <tr><td><strong>#SC-087</strong></td><td>Hendra P.</td><td>Aulia R.</td><td>Presentasi PPT</td><td><span class="badge badge-selesai">Selesai</span></td><td>Rp 50.000</td><td>18 Jan 2025</td></tr>
            <tr><td><strong>#SC-086</strong></td><td>Nanda R.</td><td>Aidil D.</td><td>Video Reels</td><td><span class="badge badge-batal">Dibatalkan</span></td><td>Rp 100.000</td><td>15 Jan 2025</td></tr>
            <tr><td><strong>#SC-085</strong></td><td>Eko S.</td><td>Ibrahim N.</td><td>Bimbel Python</td><td><span class="badge badge-selesai">Selesai</span></td><td>Rp 80.000</td><td>14 Jan 2025</td></tr>
            <tr><td><strong>#SC-084</strong></td><td>Lita F.</td><td>Fajar R.</td><td>Website</td><td><span class="badge badge-selesai">Selesai</span></td><td>Rp 350.000</td><td>10 Jan 2025</td></tr>
          </tbody>
        </table>
      </div>
    </div>

    <!-- ═══ LAPORAN ═══ -->
    <div class="panel" id="panel-laporan">
      <div class="stats-grid">
        <div class="stat-card"><div class="stat-top"><div class="stat-icon" style="background:#d0e8f7;">📅</div><span class="stat-trend trend-up">↑ 18%</span></div><div class="stat-val">Rp 12,4Jt</div><div class="stat-lbl">Pendapatan Bulan Ini</div></div>
        <div class="stat-card"><div class="stat-top"><div class="stat-icon" style="background:#c8dcf5;">📋</div><span class="stat-trend trend-up">↑ 34</span></div><div class="stat-val">247</div><div class="stat-lbl">Transaksi Bulan Ini</div></div>
        <div class="stat-card"><div class="stat-top"><div class="stat-icon" style="background:#ddeaf7;">👥</div><span class="stat-trend trend-up">↑ 12</span></div><div class="stat-val">48</div><div class="stat-lbl">Pengguna Baru</div></div>
        <div class="stat-card"><div class="stat-top"><div class="stat-icon" style="background:#b8cce8;">⭐</div><span class="stat-trend trend-up">+0.1</span></div><div class="stat-val">4.87</div><div class="stat-lbl">Rata-rata Rating</div></div>
      </div>
      <div class="card" style="margin-bottom:1rem;">
        <div class="card-header"><h3>📊 Statistik Bulanan</h3><button class="tbl-btn success" onclick="showToast('📥 Laporan diunduh!')">⬇️ Export CSV</button></div>
        <table class="data-table">
          <thead><tr><th>Bulan</th><th>Pengguna Baru</th><th>Jasa Baru</th><th>Transaksi</th><th>Pendapatan</th><th>Rating</th></tr></thead>
          <tbody>
            <tr><td>Januari 2025</td><td>48</td><td>23</td><td>247</td><td>Rp 12.400.000</td><td>⭐ 4.87</td></tr>
            <tr><td>Desember 2024</td><td>36</td><td>18</td><td>213</td><td>Rp 10.500.000</td><td>⭐ 4.85</td></tr>
            <tr><td>November 2024</td><td>29</td><td>14</td><td>189</td><td>Rp 9.200.000</td><td>⭐ 4.82</td></tr>
            <tr><td>Oktober 2024</td><td>22</td><td>11</td><td>156</td><td>Rp 7.800.000</td><td>⭐ 4.80</td></tr>
          </tbody>
        </table>
      </div>
    </div>

    <!-- ═══ PENGATURAN ═══ -->
    <div class="panel" id="panel-pengaturan">
      <div class="two-col">
        <div class="card">
          <div class="card-header"><h3>⚙️ Pengaturan Platform</h3></div>
          <div class="setting-section">
            <h4>Umum</h4>
            <div class="setting-row"><div class="setting-info"><div class="title">Registrasi Pengguna Baru</div><div class="desc">Izinkan pengguna baru mendaftar</div></div><div class="toggle on" onclick="this.classList.toggle('on')"></div></div>
            <div class="setting-row"><div class="setting-info"><div class="title">Verifikasi Email</div><div class="desc">Wajibkan verifikasi email saat daftar</div></div><div class="toggle on" onclick="this.classList.toggle('on')"></div></div>
            <div class="setting-row"><div class="setting-info"><div class="title">Mode Maintenance</div><div class="desc">Nonaktifkan akses publik sementara</div></div><div class="toggle" onclick="this.classList.toggle('on')"></div></div>
          </div>
          <div class="setting-section">
            <h4>Jasa & Transaksi</h4>
            <div class="setting-row"><div class="setting-info"><div class="title">Persetujuan Jasa Baru</div><div class="desc">Jasa baru harus disetujui admin</div></div><div class="toggle on" onclick="this.classList.toggle('on')"></div></div>
            <div class="setting-row"><div class="setting-info"><div class="title">Notifikasi Pesanan</div><div class="desc">Kirim email saat ada pesanan baru</div></div><div class="toggle on" onclick="this.classList.toggle('on')"></div></div>
            <div class="setting-row"><div class="setting-info"><div class="title">Sistem Rating</div><div class="desc">Aktifkan fitur rating dan ulasan</div></div><div class="toggle on" onclick="this.classList.toggle('on')"></div></div>
          </div>
          <button class="tbl-btn success" onclick="showToast('✅ Pengaturan disimpan!')">Simpan Pengaturan</button>
        </div>
        <div class="card">
          <div class="card-header"><h3>ℹ️ Informasi Sistem</h3></div>
          <div style="font-size:0.82rem; color:var(--text-muted); line-height:2;">
            <div style="display:flex; justify-content:space-between;"><span>Versi Aplikasi</span><strong style="color:var(--dark)">v1.0.0</strong></div>
            <div style="display:flex; justify-content:space-between;"><span>PHP Version</span><strong style="color:var(--dark)">8.2.x</strong></div>
            <div style="display:flex; justify-content:space-between;"><span>Database</span><strong style="color:var(--dark)">MySQL 8.0</strong></div>
            <div style="display:flex; justify-content:space-between;"><span>Total Storage</span><strong style="color:var(--dark)">2.4 GB / 10 GB</strong></div>
            <div style="display:flex; justify-content:space-between;"><span>Status Server</span><strong style="color:#018BD8">🟢 Online</strong></div>
            <div style="display:flex; justify-content:space-between;"><span>Last Backup</span><strong style="color:var(--dark)">24 Jan 2025</strong></div>
          </div>
          <div style="margin-top:1rem; display:flex; flex-direction:column; gap:8px;">
            <button class="tbl-btn" onclick="showToast('🔄 Cache berhasil dibersihkan!')">🗑️ Bersihkan Cache</button>
            <button class="tbl-btn" onclick="showToast('💾 Backup dimulai!')">💾 Buat Backup Manual</button>
          </div>
        </div>
      </div>
    </div>

  </div>
</div>

<!-- MODAL KONFIRMASI -->
<div class="modal-overlay" id="confirmModal" onclick="closeModal(event)">
  <div class="modal-box">
    <h3 id="confirmTitle">Konfirmasi Aksi</h3>
    <p id="confirmMsg">Apakah kamu yakin ingin melanjutkan aksi ini?</p>
    <div class="modal-btns">
      <button class="btn-cancel" onclick="document.getElementById('confirmModal').classList.remove('show')">Batal</button>
      <button class="btn-confirm" id="confirmBtn">Ya, Lanjutkan</button>
    </div>
  </div>
</div>

<!-- TOAST -->
<div class="toast" id="toast">✅ <span id="toastMsg"></span></div>

<script>
  function showPanel(name, el) {
    document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
    document.getElementById('panel-' + name).classList.add('active');
    if (el) { document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active')); el.classList.add('active'); }
    const titles = { overview:['Admin Overview','Ringkasan aktivitas platform SkillCampus'], users:['Kelola Pengguna','Manajemen akun dan verifikasi pengguna'], jasa:['Kelola Jasa','Review dan moderasi jasa yang ditawarkan'], transaksi:['Transaksi','Riwayat dan monitoring semua transaksi'], laporan:['Laporan & Statistik','Analitik dan performa platform'], pengaturan:['Pengaturan Sistem','Konfigurasi platform SkillCampus'] };
    if (titles[name]) { document.getElementById('topbarTitle').textContent = titles[name][0]; document.getElementById('topbarSub').textContent = titles[name][1]; }
  }

  function searchTable(input, tableId) {
    const keyword = input.value.toLowerCase();
    const rows = document.querySelectorAll('#' + tableId + ' tbody tr');
    rows.forEach(row => { row.style.display = row.textContent.toLowerCase().includes(keyword) ? '' : 'none'; });
  }

  function filterTable(sel, tableId, colIdx) {
    const val = sel.value.toLowerCase();
    document.querySelectorAll('#' + tableId + ' tbody tr').forEach(row => {
      const cell = row.cells[colIdx];
      row.style.display = (!val || (cell && cell.textContent.toLowerCase().includes(val))) ? '' : 'none';
    });
  }

  function confirmSuspend(btn) {
    const row = btn.closest('tr');
    const name = row.querySelector('.un').textContent;
    document.getElementById('confirmTitle').textContent = 'Suspend Pengguna';
    document.getElementById('confirmMsg').textContent = `Apakah kamu yakin ingin men-suspend akun "${name}"?`;
    document.getElementById('confirmBtn').onclick = () => {
      const badges = row.querySelectorAll('.badge');
      const badge = badges.length ? badges[badges.length - 1] : null;
      if (badge) { badge.className = 'badge badge-nonaktif'; badge.textContent = 'Nonaktif'; }
      btn.outerHTML = '<button class="tbl-btn success" onclick="activateUser(this)">Aktifkan</button>';
      document.getElementById('confirmModal').classList.remove('show');
      showToast('🚫 Pengguna disuspend');
    };
    document.getElementById('confirmModal').classList.add('show');
  }

  function activateUser(btn) {
    const row = btn.closest('tr');
    const badges = row.querySelectorAll('.badge');
    const statusBadge = badges[badges.length - 1];
    statusBadge.className = 'badge badge-aktif'; statusBadge.textContent = 'Aktif';
    btn.outerHTML = '<button class="tbl-btn" onclick="showToast(\'👁️ Detail pengguna\')">Detail</button> <button class="tbl-btn danger" onclick="confirmSuspend(this)">Suspend</button>';
    showToast('✅ Pengguna diaktifkan!');
  }

  function approveJasa(btn) {
    const row = btn.closest('tr');
    const badge = row.querySelector('.badge');
    badge.className = 'badge badge-aktif'; badge.textContent = 'Aktif';
    btn.parentElement.innerHTML = '<button class="tbl-btn" onclick="showToast(\'👁️ Detail jasa\')">Detail</button> <button class="tbl-btn danger" onclick="removeJasa(this)">Hapus</button>';
    showToast('✅ Jasa disetujui dan aktif!');
  }

  function removeJasa(btn) {
    document.getElementById('confirmTitle').textContent = 'Hapus Jasa';
    document.getElementById('confirmMsg').textContent = 'Apakah kamu yakin ingin menghapus jasa ini? Aksi ini tidak dapat dibatalkan.';
    document.getElementById('confirmBtn').onclick = () => {
      btn.closest('tr').remove();
      document.getElementById('confirmModal').classList.remove('show');
      showToast('🗑️ Jasa dihapus');
    };
    document.getElementById('confirmModal').classList.add('show');
  }

  function closeModal(e) { if (e.target.id === 'confirmModal') document.getElementById('confirmModal').classList.remove('show'); }

  let toastTimer;
  function showToast(msg) {
    const t = document.getElementById('toast');
    document.getElementById('toastMsg').textContent = msg;
    t.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => t.classList.remove('show'), 2800);
  }
</script>
</body>
</html>