<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../login.php');
    exit;
}

require_once '../config/koneksi.php';

// ── LOGIKA AKSI KONTROL: UPDATE STATUS TRANSAKSI ──
if (isset($_GET['aksi']) && isset($_GET['id_pesanan'])) {
    $id_p = (int)$_GET['id_pesanan'];
    $aksi = $_GET['aksi'];
    
    if ($aksi === 'selesai') {
        mysqli_query($koneksi, "UPDATE pesanan SET status = 'Selesai' WHERE id = $id_p");
    } elseif ($aksi === 'batal') {
        mysqli_query($koneksi, "UPDATE pesanan SET status = 'Dibatalkan' WHERE id = $id_p");
    }
    
    header("Location: dashboard.php");
    exit;
}

// ── LOGIKA AKSI KONTROL: APPROVAL JASA BARU OLEH ADMIN ──
if (isset($_GET['persetujuan']) && isset($_GET['id_jasa'])) {
    $id_j = (int)$_GET['id_jasa'];
    $status_jasa = $_GET['persetujuan'] === 'setuju' ? 'Disetujui' : 'Ditolak';
    
    mysqli_query($koneksi, "UPDATE jasa SET status_jasa = '$status_jasa' WHERE id = $id_j");
    header("Location: dashboard.php");
    exit;
}

// ── STAT CARDS ──────────────────────────────────────────
$total_users   = mysqli_fetch_row(mysqli_query($koneksi, "SELECT COUNT(*) FROM users WHERE role='user'"))[0];
$total_jasa    = mysqli_fetch_row(mysqli_query($koneksi, "SELECT COUNT(*) FROM jasa"))[0];
$total_pesanan = mysqli_fetch_row(mysqli_query($koneksi, "SELECT COUNT(*) FROM pesanan"))[0];
$volume        = mysqli_fetch_row(mysqli_query($koneksi, "SELECT COALESCE(SUM(j.harga),0) FROM pesanan p JOIN jasa j ON p.jasa_id=j.id WHERE p.status='Selesai'"))[0];

// ── PANEL USERS ──────────────────────────────────────────
$users = mysqli_query($koneksi, "SELECT id, nama, email, role FROM users ORDER BY id DESC");

// ── PANEL JASA ───────────────────────────────────────────
$jasas = mysqli_query($koneksi, "
    SELECT j.id, j.judul, j.kategori, j.harga, j.status_jasa, u.nama AS penyedia,
           (SELECT COUNT(*) FROM pesanan p WHERE p.jasa_id=j.id) AS jumlah_pesanan
    FROM jasa j
    LEFT JOIN users u ON j.user_id=u.id
    ORDER BY j.id DESC
");

// ── PANEL TRANSAKSI ──────────────────────────────────────
$transaksis = mysqli_query($koneksi, "
    SELECT p.id,
           pemesan.nama AS nama_pemesan,
           penyedia.nama AS penyedia,
           j.judul AS nama_jasa,
           p.status, j.harga, p.tanggal
    FROM pesanan p
    LEFT JOIN jasa j        ON p.jasa_id  = j.id
    LEFT JOIN users pemesan  ON p.user_id   = pemesan.id
    LEFT JOIN users penyedia ON j.user_id   = penyedia.id
    ORDER BY p.tanggal DESC
");

// ── PANEL LAPORAN ────────────────────────────────────────
$pendapatan_bulan = mysqli_fetch_row(mysqli_query($koneksi, "
    SELECT COALESCE(SUM(j.harga),0) FROM pesanan p
    JOIN jasa j ON p.jasa_id=j.id
    WHERE p.status='Selesai' AND MONTH(p.tanggal)=MONTH(NOW()) AND YEAR(p.tanggal)=YEAR(NOW())
"))[0];
$pesanan_bulan = mysqli_fetch_row(mysqli_query($koneksi, "
    SELECT COUNT(*) FROM pesanan
    WHERE MONTH(tanggal)=MONTH(NOW()) AND YEAR(tanggal)=YEAR(NOW())
"))[0];
$avg_rating = mysqli_fetch_row(mysqli_query($koneksi, "SELECT COALESCE(ROUND(AVG(rating),2),0) FROM ulasan"))[0];

// ── OVERVIEW: recent users ───────────────────────────────
$recent_users = mysqli_query($koneksi, "SELECT nama, email, role FROM users ORDER BY id DESC LIMIT 4");

// ── OVERVIEW: recent pesanan ─────────────────────────────
$recent_pesanan = mysqli_query($koneksi, "
    SELECT p.id, u.nama AS nama_pemesan, j.judul, p.status, p.tanggal
    FROM pesanan p
    LEFT JOIN jasa j  ON p.jasa_id = j.id
    LEFT JOIN users u ON p.user_id = u.id
    ORDER BY p.tanggal DESC LIMIT 5
");

// ── BAR CHART: pesanan 7 hari terakhir ───────────────────
$bar_data = [];
for ($i = 6; $i >= 0; $i--) {
    $r = mysqli_fetch_row(mysqli_query($koneksi, "
        SELECT COUNT(*) FROM pesanan
        WHERE DATE(tanggal) = DATE(NOW() - INTERVAL $i DAY)
    "));
    $bar_data[] = $r[0];
}
$bar_max = max(array_merge($bar_data, [1]));
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Admin Panel Workspace — SkillCampus</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet"/>
  <style>
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    :root {
      --ink:           #0a0f1e;
      --ink2:          #1e2740;
      --blue:          #2563eb;
      --blue2:         #1d4ed8;
      --sky:           #38bdf8;
      --muted:         #64748b;
      --border:        rgba(148, 163, 184, 0.12);
      --glass-bg:      rgba(10, 15, 30, 0.7);
      --surface-card:  rgba(255, 255, 255, 0.03);
      
      /* FIX CONTAINER UTAMA: Putih Solid tapi Lembut Elegan */
      --white-container: #ffffff;
      --text-dark:       #0f172a;
      --text-muted-dark: #475569;
      --border-dark:     #e2e8f0;
      
      --radius-lg:     24px;
      --radius-md:     14px;
      --sidebar:       270px;
      
      --red:           #ef4444;
      --green:         #10b981;
      --amber:         #f59e0b;
    }
    
    html, body {
      height: 100%;
      font-family: 'Inter', sans-serif;
      -webkit-font-smoothing: antialiased;
      background: #050a18;
      overflow-x: hidden;
    }

    #bg-canvas { position: fixed; inset: 0; z-index: 0; pointer-events: none; }

    .page-layout { position: relative; z-index: 1; display: flex; min-height: 100vh; }

    /* =================== SIDEBAR (TETAP GLASS MEWAH) =================== */
    .sidebar { 
      width: var(--sidebar); background: var(--glass-bg); backdrop-filter: blur(20px); -webkit-backdrop-filter: blur(20px); 
      color: #94a3b8; display: flex; flex-direction: column; position: fixed; top: 0; left: 0; bottom: 0; z-index: 50; 
      border-right: 1px solid var(--border);
    }
    .sidebar-logo { padding: 2rem 1.5rem 1.5rem; border-bottom: 1px solid var(--border); }
    .sidebar-logo .brand { font-size: 1.35rem; font-weight: 800; color: white; letter-spacing: -0.75px; display: flex; align-items: center; gap: 8px; }
    .sidebar-logo .brand span { background: linear-gradient(90deg, #60a5fa, #38bdf8); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text; }
    .sidebar-logo .sub { font-size: 0.72rem; color: var(--muted); margin-top: 6px; display: flex; align-items: center; gap: 6px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em; }
    .sidebar-logo .sub::before { content: ''; width: 6px; height: 6px; background: #10b981; border-radius: 50%; box-shadow: 0 0 8px #10b981; }
    
    .admin-profile { padding: 1.25rem 1.5rem; display: flex; align-items: center; gap: 12px; border-bottom: 1px solid var(--border); background: rgba(15, 23, 42, 0.2); }
    .admin-avatar { width: 42px; height: 42px; border-radius: 12px; background: linear-gradient(135deg, #2563eb, #38bdf8); display: flex; align-items: center; justify-content: center; font-size: 1.2rem; flex-shrink: 0; box-shadow: 0 4px 14px rgba(37, 99, 235, 0.4); }
    .admin-info .name { font-size: 0.9rem; font-weight: 700; color: white; letter-spacing: -0.2px; }
    .admin-info .role { font-size: 0.75rem; color: var(--muted); font-weight: 600; margin-top: 1px; }
    .admin-badge { margin-left: auto; font-size: 0.65rem; font-weight: 800; background: rgba(56, 189, 248, 0.1); color: var(--sky); padding: 3px 8px; border-radius: 6px; border: 1px solid rgba(56, 189, 248, 0.15); }
    
    .sidebar-nav { flex: 1; padding: 1.25rem 0.75rem; overflow-y: auto; display: flex; flex-direction: column; gap: 4px; }
    .nav-section { padding: 0.75rem 0.75rem 0.5rem; font-size: 0.65rem; font-weight: 800; letter-spacing: 0.15em; text-transform: uppercase; color: var(--muted); }
    .nav-item { display: flex; align-items: center; gap: 12px; padding: 11px 14px; font-size: 0.9rem; font-weight: 600; color: rgba(255,255,255,0.6); cursor: pointer; transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1); border-radius: 10px; text-decoration: none; }
    .nav-item:hover { color: white; background: rgba(255, 255, 255, 0.04); transform: translateX(3px); }
    .nav-item.active { color: white; background: rgba(37, 99, 235, 0.15); font-weight: 700; box-shadow: inset 0 0 12px rgba(37,99,235,0.2), 0 0 0 1px rgba(37,99,235,0.3); }
    .nav-item .icon { width: 20px; text-align: center; font-size: 1.05rem; }
    .sidebar-footer { padding: 1.25rem; border-top: 1px solid var(--border); }
    .sidebar-footer a { font-size: 0.875rem; color: var(--muted); text-decoration: none; display: flex; align-items: center; gap: 8px; transition: color 0.15s; font-weight: 600; }
    .sidebar-footer a:hover { color: #f87171; }

    /* =================== MAIN PANEL =================== */
    .main { margin-left: var(--sidebar); flex: 1; display: flex; flex-direction: column; min-width: 0; }
    
    .topbar { background: rgba(10, 15, 30, 0.65); border-bottom: 1px solid var(--border); display: flex; align-items: center; justify-content: space-between; padding: 0 2.5rem; height: 70px; position: sticky; top: 0; z-index: 40; backdrop-filter: blur(20px); -webkit-backdrop-filter: blur(20px); }
    .topbar-left h1 { font-size: 1.35rem; font-weight: 800; color: #ffffff; letter-spacing: -0.5px; }
    .topbar-left p { font-size: 0.8rem; color: var(--muted); margin-top: 2px; font-weight: 500; }
    .topbar-right { display: flex; align-items: center; gap: 14px; }
    .topbar-btn { width: 40px; height: 40px; border-radius: 12px; border: 1px solid var(--border); background: var(--surface-card); cursor: pointer; display: flex; align-items: center; justify-content: center; font-size: 1.05rem; color: #fff; transition: all 0.2s; }
    .topbar-btn:hover { background: rgba(255,255,255,0.08); transform: translateY(-1px); }
    .search-bar { display: flex; align-items: center; gap: 10px; background: rgba(255,255,255,0.03); border: 1px solid var(--border); border-radius: 12px; padding: 0 16px; height: 40px; transition: all 0.2s; }
    .search-bar:focus-within { background: rgba(5,10,24,0.4); border-color: var(--blue); box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.15); }
    .search-bar input { border: none; background: transparent; font-size: 0.875rem; font-family: inherit; outline: none; width: 220px; color: #fff; font-weight: 500; }
    .search-bar input::placeholder { color: rgba(255,255,255,0.25); }
    
    .content { padding: 2.5rem; flex: 1; }
    .panel { display: none; }
    .panel.active { display: block; animation: slideUpFade 0.4s cubic-bezier(0.16, 1, 0.3, 1) forwards; }

    @keyframes slideUpFade { from { opacity: 0; transform: translateY(15px); } to { opacity: 1; transform: translateY(0); } }

    /* STATS CARDS tetap glassmorphic melayang biar keren */
    .stats-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 1.5rem; margin-bottom: 2.5rem; }
    .stat-card { background: var(--glass-bg); backdrop-filter: blur(10px); border-radius: var(--radius-lg); padding: 1.5rem; border: 1px solid var(--border); box-shadow: 0 20px 40px rgba(0,0,0,0.2); transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275); display: flex; flex-direction: column; justify-content: space-between; }
    .stat-card:hover { transform: translateY(-4px); border-color: rgba(56, 189, 248, 0.3); box-shadow: 0 30px 60px rgba(0,0,0,0.4); }
    .stat-top { display: flex; align-items: center; justify-content: space-between; margin-bottom: 14px; }
    .stat-icon { width: 44px; height: 44px; border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 1.25rem; font-weight: bold; border: 1px solid var(--border); }
    .stat-val { font-size: 1.9rem; font-weight: 800; color: #fff; letter-spacing: -0.8px; line-height: 1; }
    .stat-lbl { font-size: 0.82rem; font-weight: 600; color: var(--muted); margin-top: 8px; }
    .stat-trend { font-size: 0.72rem; font-weight: 700; display: inline-flex; align-items: center; gap: 4px; padding: 2px 7px; border-radius: 6px; width: fit-content; }
    .trend-up { background: rgba(16, 185, 129, 0.1); color: #34d399; border: 1px solid rgba(16, 185, 129, 0.2); }

    /* =================== FIX UTAMA: CONTAINER PUTIH ANTI PLONG =================== */
    .card { 
      background: var(--white-container); /* Mengubah latar belakang menjadi putih solid murni */
      border-radius: var(--radius-lg); 
      border: 1px solid var(--border-dark); 
      padding: 2rem; 
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.04); 
      margin-bottom: 2rem; 
      color: var(--text-dark); /* Mengubah warna font kontainer ini agar kontras */
    }
    .card-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 1.5rem; }
    .card-header h3 { font-size: 1.05rem; font-weight: 800; color: var(--text-dark); letter-spacing: -0.3px; display: flex; align-items: center; gap: 8px; }
    .card-header a { color: var(--blue); font-weight: 700; text-decoration: none; transition: color 0.15s; }
    .card-header a:hover { color: var(--blue2); }
    
    .two-col { display: grid; grid-template-columns: 1fr 1fr; gap: 2rem; margin-bottom: 2rem; }
    .three-two { display: grid; grid-template-columns: 3fr 2fr; gap: 2rem; margin-bottom: 2rem; }

    /* DATA TABLES DESIGN (MENYATU DENGAN BASE PUTIH) */
    .table-container { border-radius: var(--radius-md); border: 1px solid var(--border-dark); overflow: hidden; background: #ffffff; }
    .data-table { width: 100%; border-collapse: collapse; }
    .data-table th { font-size: 0.75rem; font-weight: 800; text-transform: uppercase; letter-spacing: 0.08em; color: var(--text-muted-dark); text-align: left; padding: 14px 20px; background: #f8fafc; border-bottom: 1px solid var(--border-dark); white-space: nowrap; }
    .data-table td { font-size: 0.88rem; padding: 14px 20px; border-bottom: 1px solid #f1f5f9; color: var(--text-dark); font-weight: 500; }
    .data-table tr:last-child td { border-bottom: none; }
    .data-table tr { transition: background 0.15s; }
    .data-table tr:hover td { background: #fafafa; }

    /* BADGES */
    .badge { font-size: 0.72rem; font-weight: 700; padding: 4px 9px; border-radius: 6px; display: inline-block; border: 1px solid transparent; text-align: center; }
    .badge-user    { background: #e0f2fe; color: #0369a1; border-color: #bae6fd; }
    .badge-admin   { background: #f1f5f9; color: #475569; border-color: #e2e8f0; }
    
    .badge-selesai { background: #dcfce7; color: #15803d; border-color: #bbf7d0; }
    .badge-proses  { background: #dbeafe; color: #1d4ed8; border-color: #bfdbfe; }
    .badge-batal   { background: #fee2e2; color: #b91c1c; border-color: #fecaca; }
    
    .badge-approved { background: #dcfce7; color: #15803d; border-color: #bbf7d0; }
    .badge-pending  { background: #fef9c3; color: #a16207; border-color: #fef08a; }
    .badge-rejected { background: #fee2e2; color: #b91c1c; border-color: #fecaca; }

    /* ACTION BUTTONS */
    .tbl-btn { font-size: 0.78rem; font-weight: 700; padding: 6px 12px; border-radius: 8px; border: 1px solid var(--border-dark); background: #ffffff; cursor: pointer; font-family: inherit; transition: all 0.15s; display: inline-flex; align-items: center; gap: 6px; text-decoration: none; color: var(--text-muted-dark); }
    .tbl-btn:hover { border-color: #cbd5e1; background: #f8fafc; color: #000; transform: translateY(-1px); }
    .tbl-btn.danger { color: #ef4444; border-color: #fecaca; background: #fff5f5; }
    .tbl-btn.danger:hover { background: #fee2e2; border-color: #ef4444; color: #b91c1c; }
    .tbl-btn.success { background: linear-gradient(135deg, #2563eb, #1d4ed8); color: white; border-color: #1d4ed8; box-shadow: 0 4px 12px rgba(37,99,235,0.15); }
    .tbl-btn.success:hover { box-shadow: 0 6px 16px rgba(37,99,235,0.25); }
    .tbl-btn.approve-ok { background: linear-gradient(135deg, #10b981, #059669); color: white; border-color: #059669; box-shadow: 0 4px 12px rgba(16,185,129,0.15); }
    .tbl-btn.approve-ok:hover { box-shadow: 0 6px 16px rgba(16,185,129,0.25); }

    /* AVATAR SYSTEM */
    .user-cell { display: flex; align-items: center; gap: 12px; }
    .user-cell .av { width: 34px; height: 34px; border-radius: 50%; background: #eff6ff; display: flex; align-items: center; justify-content: center; font-size: 0.85rem; font-weight: 700; flex-shrink: 0; color: #1d4ed8; border: 1px solid #bfdbfe; }
    .user-cell .un { font-weight: 700; font-size: 0.88rem; color: var(--text-dark); }
    .user-cell .ue { font-size: 0.78rem; color: var(--text-muted-dark); margin-top: 1px; }

    /* TOOLBAR CONTROLS */
    .toolbar { display: flex; align-items: center; gap: 14px; margin-bottom: 1.5rem; flex-wrap: wrap; }
    .toolbar input[type="text"] { padding: 9px 14px; border: 1.5px solid var(--border-dark); border-radius: 10px; font-size: 0.85rem; font-family: inherit; outline: none; transition: all 0.2s; background: #ffffff; width: 260px; color: var(--text-dark); }
    .toolbar input:focus { border-color: var(--blue); box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1); }
    .toolbar select { padding: 9px 14px; border: 1.5px solid var(--border-dark); border-radius: 10px; font-size: 0.85rem; font-family: inherit; outline: none; background: #ffffff; cursor: pointer; font-weight: 600; color: var(--text-muted-dark); }

    /* FEED LOG LINE */
    .feed-item { display: flex; align-items: center; gap: 14px; padding: 12px 0; border-bottom: 1px solid #f1f5f9; }
    .feed-item:last-child { border-bottom: none; }
    .feed-icon { width: 36px; height: 36px; border-radius: 10px; display: flex; align-items: center; justify-content: center; font-size: 1.1rem; flex-shrink: 0; background: #f8fafc; border: 1px solid var(--border-dark); color: var(--blue); }
    .feed-text { flex: 1; font-size: 0.85rem; color: var(--text-muted-dark); line-height: 1.5; }
    .feed-text strong { color: var(--text-dark); font-weight: 700; }
    .feed-time { font-size: 0.78rem; font-weight: 600; color: var(--text-muted-dark); }

    /* SETTING INTERFACES */
    .setting-section { margin-bottom: 1.75rem; }
    .setting-section h4 { font-size: 0.82rem; font-weight: 800; color: var(--text-dark); margin-bottom: 1.25rem; padding-bottom: 8px; border-bottom: 2px solid #f1f5f9; text-transform: uppercase; letter-spacing: 0.08em; }
    .setting-section .setting-row { display: flex; align-items: center; justify-content: space-between; padding: 12px 0; border-bottom: 1px solid #f8fafc; }
    .setting-section .setting-row:last-child { border-bottom: none; }
    .setting-info .title { font-size: 0.9rem; font-weight: 700; color: var(--text-dark); }
    .setting-info .desc { font-size: 0.78rem; color: var(--text-muted-dark); margin-top: 2px; font-weight: 500; }
    
    .toggle { width: 44px; height: 24px; background: #cbd5e1; border-radius: 50px; position: relative; cursor: pointer; transition: background 0.2s; flex-shrink: 0; border: 1px solid transparent; }
    .toggle.on { background: #10b981; }
    .toggle::after { content: ''; position: absolute; width: 18px; height: 18px; background: white; border-radius: 50%; top: 3px; left: 3px; transition: left 0.2s; }
    .toggle.on::after { left: 22px; }

    /* TOAST */
    .toast { position: fixed; bottom: 2rem; right: 2rem; background: var(--ink2); color: white; padding: 14px 24px; border-radius: 12px; font-size: 0.88rem; font-weight: 700; box-shadow: 0 10px 30px rgba(0,0,0,0.5); z-index: 999; display: none; align-items: center; gap: 10px; border: 1px solid var(--border); }
    .toast.show { display: flex; }

    /* MODAL */
    .modal-overlay { display: none; position: fixed; inset: 0; background: rgba(5, 10, 24, 0.6); backdrop-filter: blur(4px); -webkit-backdrop-filter: blur(4px); z-index: 200; align-items: center; justify-content: center; padding: 1rem; }
    .modal-overlay.show { display: flex; }
    .modal-box { background: #ffffff; border-radius: var(--radius-lg); border: 1px solid var(--border-dark); padding: 2rem; max-width: 480px; width: 100%; box-shadow: 0 30px 70px rgba(0,0,0,0.2); }
    .modal-box h3 { font-size: 1.15rem; font-weight: 800; margin-bottom: 0.75rem; color: var(--text-dark); letter-spacing: -0.3px; }
    .modal-box p { font-size: 0.88rem; color: var(--text-muted-dark); margin-bottom: 1.75rem; line-height: 1.6; font-weight: 500; }
    .modal-btns { display: flex; gap: 10px; justify-content: flex-end; }
    .btn-confirm { padding: 10px 24px; background: linear-gradient(135deg, #ef4444, #dc2626); color: white; border: none; border-radius: 10px; font-size: 0.875rem; font-weight: 700; cursor: pointer; font-family: inherit; box-shadow: 0 4px 12px rgba(239,68,68,0.2); }
    .btn-confirm:hover { transform: translateY(-0.5px); box-shadow: 0 6px 16px rgba(239,68,68,0.3); }
    .btn-cancel { padding: 10px 24px; border: 1px solid var(--border-dark); background: transparent; border-radius: 10px; font-size: 0.875rem; font-weight: 600; cursor: pointer; font-family: inherit; color: var(--text-muted-dark); }
    .btn-cancel:hover { background: #f8fafc; color: var(--text-dark); }

    @media (max-width: 900px) { .main { margin-left: 0; } .sidebar { display:none; } .stats-grid { grid-template-columns: 1fr 1fr; } .two-col, .three-two { grid-template-columns: 1fr; } }
  </style>
</head>
<body>

<canvas id="bg-canvas"></canvas>

<div class="page-layout">

  <aside class="sidebar">
    <div class="sidebar-logo">
      <div class="brand">Skill<span>Campus</span></div>
      <div class="sub">Admin Panel · Sistem Aktif</div>
    </div>
    <div class="admin-profile">
      <div class="admin-avatar">🛡️</div>
      <div class="admin-info">
        <div class="name"><?= htmlspecialchars($_SESSION['username'] ?? 'Administrator') ?></div>
        <div class="role">Super Admin</div>
      </div>
      <div class="admin-badge">ADMIN</div>
    </div>
    <nav class="sidebar-nav">
      <div class="nav-section">Dashboard</div>
      <a class="nav-item active" onclick="showPanel('overview', this)"><span class="icon">📊</span> Overview</a>
      <div class="nav-section">Manajemen</div>
      <a class="nav-item" onclick="showPanel('users', this)"><span class="icon">👥</span> Kelola Pengguna</a>
      <a class="nav-item" onclick="showPanel('jasa', this)"><span class="icon">💼</span> Kelola Jasa</a>
      <a class="nav-item" onclick="showPanel('transaksi', this)"><span class="icon">💳</span> Transaksi</a>
      <a class="nav-item" onclick="showPanel('laporan', this)"><span class="icon">📈</span> Laporan</a>
      <div class="nav-section">Sistem</div>
      <a class="nav-item" onclick="showPanel('pengaturan', this)"><span class="icon">⚙️</span> Pengaturan</a>
    </nav>
    <div class="sidebar-footer">
      <a href="../logout.php">🚪 Keluar dari Admin</a>
    </div>
  </aside>

  <div class="main">
    <header class="topbar">
      <div class="topbar-left">
        <h1 id="topbarTitle">Admin Overview</h1>
        <p id="topbarSub">Ringkasan aktivitas platform SkillCampus</p>
      </div>
      <div class="topbar-right">
        <div class="search-bar">
          <span>🔍</span>
          <input type="text" placeholder="Cari di panel..." />
        </div>
        <button class="topbar-btn">🔔</button>
        <button class="topbar-btn">🛡️</button>
      </div>
    </header>

    <div class="content">

      <?php if(isset($_GET['msg']) && $_GET['msg'] == 'success'): ?>
        <div class="notif-box notif-success" style="background:#dcfce7; color:#15803d; border:1px solid #bbf7d0; padding:12px 18px; border-radius:10px; margin-bottom:20px; font-weight:600;">
          <span>✅ Aksi Berhasil Dieksekusi!</span>
        </div>
      <?php endif; ?>

      <div class="panel active" id="panel-overview">
        <div class="stats-grid">
          <div class="stat-card">
            <div class="stat-top"><div class="stat-icon" style="background:rgba(56, 189, 248, 0.08); color:var(--sky);">👥</div><span class="stat-trend trend-up">▲ 4%</span></div>
            <div class="stat-val"><?= $total_users ?></div>
            <div class="stat-lbl">Total Pengguna</div>
          </div>
          <div class="stat-card">
            <div class="stat-top"><div class="stat-icon" style="background:rgba(245, 158, 11, 0.08); color:var(--amber);">💼</div><span class="stat-trend trend-up">▲ 8%</span></div>
            <div class="stat-val"><?= $total_jasa ?></div>
            <div class="stat-lbl">Jasa Terdaftar</div>
          </div>
          <div class="stat-card">
            <div class="stat-top"><div class="stat-icon" style="background:rgba(16, 185, 129, 0.08); color:var(--green);">💳</div><span class="stat-trend trend-up">▲ 12%</span></div>
            <div class="stat-val"><?= $total_pesanan ?></div>
            <div class="stat-lbl">Total Pesanan</div>
          </div>
          <div class="stat-card">
            <div class="stat-top"><div class="stat-icon" style="background:rgba(139, 92, 246, 0.08); color:#a78bfa;">💰</div><span class="stat-trend trend-up" style="background:rgba(37,99,235,0.15); color:var(--sky);">Target 90%</span></div>
            <div class="stat-val">Rp <?= number_format($volume, 0, ',', '.') ?></div>
            <div class="stat-lbl">Transaksi Selesai</div>
          </div>
        </div>

        <div class="three-two">
          <div class="card">
            <div class="card-header">
              <h3>📈 Tren Aktivitas Pesanan (7 Hari Terakhir)</h3>
              <span style="font-size:0.72rem; font-weight:700; color:var(--blue); background:#eff6ff; border:1px solid #bfdbfe; padding:4px 12px; border-radius:8px; text-transform:uppercase;"><?= date('F Y') ?></span>
            </div>
            
            <div style="display: flex; align-items: flex-end; justify-content: space-between; height: 160px; padding: 12px 20px 0; background: #f8fafc; border-radius: 12px; border: 1px dashed var(--border-dark); margin-top: 15px;">
              <?php foreach ($bar_data as $i => $val):
                $pct = $bar_max > 0 ? round(($val / $bar_max) * 100) : 0;
                $display_pct = max($pct, 6);
                $label = date('D', strtotime('-' . (6 - $i) . ' days'));
              ?>
              <div style="flex: 1; display: flex; flex-direction: column; align-items: center; gap: 8px; height: 100%;">
                <div style="width: 100%; max-width: 24px; height: <?= $display_pct ?>%; background: linear-gradient(180deg, #38bdf8 0%, #2563eb 100%); border-radius: 6px 6px 0 0; transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1); position: relative; margin-top: auto; cursor: pointer; box-shadow: 0 4px 12px rgba(37, 99, 235, 0.15);"
                     title="<?= $val ?> Pesanan"
                     onmouseover="this.style.filter='brightness(1.1)'; this.style.transform='scaleY(1.05)';" 
                     onmouseout="this.style.filter='none'; this.style.transform='scaleY(1)';">
                  <?php if($val > 0): ?>
                    <span style="position: absolute; top: -22px; left: 50%; transform: translateX(-50%); font-size: 10px; font-weight: 800; color: #ffffff; background: #1e293b; padding: 2px 6px; border-radius: 4px; white-space: nowrap;"><?= $val ?></span>
                  <?php endif; ?>
                </div>
                <div style="font-size: 0.72rem; font-weight: 700; color: var(--text-muted-dark); margin-bottom: 6px; text-transform: uppercase;"><?= $label ?></div>
              </div>
              <?php endforeach; ?>
            </div>
          </div>

          <div class="card">
            <div class="card-header"><h3>👥 Pengguna Terbaru</h3><a href="#" onclick="showPanel('users',null)">Lihat Semua →</a></div>
            <div class="table-container">
              <table class="data-table">
                <thead><tr><th>Pengguna</th><th>Peran</th></tr></thead>
                <tbody>
                  <?php while ($u = mysqli_fetch_assoc($recent_users)): ?>
                  <tr>
                    <td>
                      <div class="user-cell">
                        <div class="av"><?= strtoupper(substr($u['nama'],0,1)) ?></div>
                        <div>
                          <div class="un"><?= htmlspecialchars($u['nama']) ?></div>
                          <div class="ue"><?= htmlspecialchars($u['email']) ?></div>
                        </div>
                      </div>
                    </td>
                    <td><span class="badge badge-<?= $u['role'] ?>"><?= ucfirst($u['role']) ?></span></td>
                  </tr>
                  <?php endwhile; ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>

        <div class="card">
          <div class="card-header"><h3>🕐 Log Pesanan Teranyar</h3></div>
          <?php while ($p = mysqli_fetch_assoc($recent_pesanan)): ?>
          <?php
            $sc = $p['status'] === 'Selesai' ? 'selesai' : ($p['status'] === 'Dibatalkan' ? 'batal' : 'proses');
          ?>
          <div class="feed-item">
            <div class="feed-icon">💳</div>
            <div class="feed-text">
              Transaksi internal <strong>#SC-<?= str_pad($p['id'], 3, '0', STR_PAD_LEFT) ?></strong>
              oleh pembeli <strong><?= htmlspecialchars($p['nama_pemesan']) ?></strong>
              — <?= htmlspecialchars($p['judul'] ?? '-') ?>
              &nbsp;<span class="badge badge-<?= $sc ?>"><?= $p['status'] ?></span>
            </div>
            <div class="feed-time">
              <?php if ($p['status'] === 'Diproses'): ?>
                  <a href="dashboard.php?aksi=selesai&id_pesanan=<?= $p['id'] ?>" class="tbl-btn success" style="font-size:11px; padding:4px 10px;" onclick="return confirm('Selesaikan pesanan ini?')">✓ Selesai</a>
                  <a href="dashboard.php?aksi=batal&id_pesanan=<?= $p['id'] ?>" class="tbl-btn danger" style="font-size:11px; padding:4px 10px;" onclick="return confirm('Batalkan pesanan ini?')">✕</a>
              <?php else: ?>
                  <?= date('d M', strtotime($p['tanggal'])) ?>
              <?php endif; ?>
            </div>
          </div>
          <?php endwhile; ?>
        </div>
      </div>

      <div class="panel" id="panel-users">
        <div class="toolbar">
          <input type="text" placeholder="🔍 Cari nama atau email pengguna..." oninput="searchTable(this,'userTable')" />
          <select onchange="filterTable(this,'userTable',2)">
            <option value="">Semua Peran</option>
            <option value="user">User / Mahasiswa</option>
            <option value="admin">Administrator</option>
          </select>
        </div>
        <div class="card">
          <div class="table-container">
            <table class="data-table" id="userTable">
              <thead><tr><th>#</th><th>Informasi Pengguna</th><th>Hak Akses</th><th>Aksi Kontrol</th></tr></thead>
              <tbody>
                <?php
                  $no = 1;
                  mysqli_data_seek($users, 0);
                  while ($u = mysqli_fetch_assoc($users)):
                ?>
                <tr>
                  <td><?= $no++ ?></td>
                  <td>
                    <div class="user-cell">
                      <div class="av"><?= strtoupper(substr($u['nama'],0,1)) ?></div>
                      <div>
                        <div class="un"><?= htmlspecialchars($u['nama']) ?></div>
                        <div class="ue"><?= htmlspecialchars($u['email']) ?></div>
                      </div>
                    </div>
                  </td>
                  <td><span class="badge badge-<?= $u['role'] ?>"><?= ucfirst($u['role']) ?></span></td>
                  <td>
                    <?php if ($u['role'] !== 'admin'): ?>
                    <a href="#"
                       class="tbl-btn danger"
                       onclick="confirmHapus('hapus_user.php?id=<?= $u['id'] ?>', '<?= htmlspecialchars(addslashes($u['nama'])) ?>')">
                      ✕ Drop Akun
                    </a>
                    <?php else: ?>
                    <span class="badge badge-admin">Sistem Utama</span>
                    <?php endif; ?>
                  </td>
                </tr>
                <?php endwhile; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <div class="panel" id="panel-jasa">
        <div class="toolbar">
          <input type="text" placeholder="🔍 Cari nama judul penawaran..." oninput="searchTable(this,'jasaTable')" />
          <select onchange="filterTable(this,'jasaTable',2)">
            <option value="">Semua Kategori</option>
            <option value="Desain">Desain Grafis</option>
            <option value="Website">Pembuatan Website</option>
            <option value="Video">Pengeditan Video</option>
            <option value="Fotografi">Fotografi</option>
            <option value="Pengetikan">Pengetikan</option>
            <option value="Bimbel">Bimbel</option>
          </select>
        </div>
        <div class="card">
          <div class="table-container">
            <table class="data-table" id="jasaTable">
              <thead><tr><th>#</th><th>Nama Layanan Jasa</th><th>Kategori</th><th>Penyedia</th><th>Harga Jual</th><th>Order</th><th>Status Tayang</th><th>Verifikasi Admin</th></tr></thead>
              <tbody>
                <?php $no = 1; while ($j = mysqli_fetch_assoc($jasas)): 
                    $js_badge = 'badge-pending';
                    if($j['status_jasa'] === 'Disetujui') $js_badge = 'badge-approved';
                    if($j['status_jasa'] === 'Ditolak') $js_badge = 'badge-rejected';
                ?>
                <tr>
                  <td><?= $no++ ?></td>
                  <td><strong><?= htmlspecialchars($j['judul']) ?></strong></td>
                  <td><?= htmlspecialchars($j['kategori']) ?></td>
                  <td><?= htmlspecialchars($j['penyedia'] ?? 'Akun Demo') ?></td>
                  <td><strong style="color:var(--blue); font-weight: 800;">Rp <?= number_format($j['harga'], 0, ',', '.') ?></strong></td>
                  <td><span style="background:#f1f5f9; padding:2px 8px; border-radius:4px; font-weight:700; color:var(--text-dark);"><?= $j['jumlah_pesanan'] ?></span></td>
                  <td><span class="badge <?= $js_badge ?>"><?= $j['status_jasa'] ?></span></td>
                  <td>
                    <?php if($j['status_jasa'] === 'Pending'): ?>
                        <a href="dashboard.php?persetujuan=setuju&id_jasa=<?= $j['id'] ?>" class="tbl-btn approve-ok" onclick="return confirm('Terima & tayangkan jasa mahasiswa ini di katalog utama?')">✓ Terima</a>
                        <a href="dashboard.php?persetujuan=tolak&id_jasa=<?= $j['id'] ?>" class="tbl-btn danger" onclick="return confirm('Tolak pengajuan penawaran jasa ini?')">✕ Tolak</a>
                    <?php else: ?>
                        <a href="#" class="tbl-btn danger" onclick="confirmHapus('hapus_jasa.php?id=<?= $j['id'] ?>', '<?= htmlspecialchars(addslashes($j['judul'])) ?>')">✕ Drop Jasa</a>
                    <?php endif; ?>
                  </td>
                </tr>
                <?php endwhile; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <div class="panel" id="panel-transaksi">
        <div class="toolbar">
          <input type="text" placeholder="🔍 Cari transaksi via kata kunci..." oninput="searchTable(this,'transaksiTable')" />
          <select onchange="filterTable(this,'transaksiTable',4)">
            <option value="">Semua Status Proyek</option>
            <option value="Selesai">Selesai</option>
            <option value="Diproses">Diproses</option>
            <option value="Dibatalkan">Dibatalkan</option>
          </select>
        </div>
        <div class="card">
          <div class="table-container">
            <table class="data-table" id="transaksiTable">
              <thead><tr><th>ID Nota</th><th>Nama Pemesan</th><th>Nama Penyedia</th><th>Nama Produk Keahlian</th><th>Status Proyek</th><th>Harga Deal</th><th>Tanggal Pembuatan</th><th>Aksi Kontrol</th></tr></thead>
              <tbody>
                <?php while ($t = mysqli_fetch_assoc($transaksis)): ?>
                <?php
                  $sc = $t['status'] === 'Selesai' ? 'selesai' : ($t['status'] === 'Dibatalkan' ? 'batal' : 'proses');
                ?>
                <tr>
                  <td><strong>#SC-<?= str_pad($t['id'], 3, '0', STR_PAD_LEFT) ?></strong></td>
                  <td><?= htmlspecialchars($t['nama_pemesan']) ?></td>
                  <td><?= htmlspecialchars($t['penyedia'] ?? 'Demo Akun') ?></td>
                  <td><?= htmlspecialchars($t['nama_jasa'] ?? '-') ?></td>
                  <td><span class="badge badge-<?= $sc ?>"><?= $t['status'] ?></span></td>
                  <td><strong style="color:var(--green); font-weight:800;">Rp <?= number_format($t['harga'] ?? 0, 0, ',', '.') ?></strong></td>
                  <td><?= date('d M Y', strtotime($t['tanggal'])) ?></td>
                  <td>
                    <?php if ($t['status'] === 'Diproses'): ?>
                        <a href="dashboard.php?aksi=selesai&id_pesanan=<?= $t['id'] ?>" 
                           onclick="return confirm('Kunci status pesanan #SC-<?= str_pad($t['id'], 3, '0', STR_PAD_LEFT) ?> menjadi selesai?')" 
                           class="tbl-btn success">✓ Selesai</a>
                        <a href="dashboard.php?aksi=batal&id_pesanan=<?= $t['id'] ?>" 
                           onclick="return confirm('Batalkan rekapan data pesanan #SC-<?= str_pad($t['id'], 3, '0', STR_PAD_LEFT) ?>?')" 
                           class="tbl-btn danger">✕ Batal</a>
                    <?php else: ?>
                        <span style="color: #94a3b8; font-size: 11px; font-weight: 800; background:#f8fafc; padding:4px 8px; border-radius:6px; border:1px solid #e2e8f0;">🔒 TERKUNCI</span>
                    <?php endif; ?>
                  </td>
                </tr>
                <?php endwhile; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <div class="panel" id="panel-laporan">
        <div class="stats-grid">
          <div class="stat-card" style="border-top: 4px solid var(--green);">
            <div class="stat-top"><div class="stat-icon" style="background:rgba(16, 185, 129, 0.08); color:var(--green);">📅</div></div>
            <div class="stat-val">Rp <?= number_format($pendapatan_bulan, 0, ',', '.') ?></div>
            <div class="stat-lbl">Pendapatan Bulan Ini</div>
          </div>
          <div class="stat-card" style="border-top: 4px solid var(--blue);">
            <div class="stat-top"><div class="stat-icon" style="background:rgba(59, 130, 246, 0.08); color:var(--blue);">📋</div></div>
            <div class="stat-val"><?= $pesanan_bulan ?></div>
            <div class="stat-lbl">Pesanan Bulan Ini</div>
          </div>
          <div class="stat-card" style="border-top: 4px solid #7c3aed;">
            <div class="stat-top"><div class="stat-icon" style="background:rgba(124, 58, 237, 0.08); color:#7c3aed;">👥</div></div>
            <div class="stat-val"><?= $total_users ?></div>
            <div class="stat-lbl">Total Pengguna</div>
          </div>
          <div class="stat-card" style="border-top: 4px solid var(--amber);">
            <div class="stat-top"><div class="stat-icon" style="background:rgba(245, 158, 11, 0.08); color:var(--amber);">⭐</div></div>
            <div class="stat-val"><?= $avg_rating ?: '-' ?></div>
            <div class="stat-lbl">Rata-rata Rating</div>
          </div>
        </div>
      </div>

      <div class="panel" id="panel-pengaturan">
        <div class="two-col">
          <div class="card">
            <div class="card-header"><h3>⚙️ Parameter Aturan Platform</h3></div>
            <div class="setting-section">
              <h4>Fungsi Notifikasi & Transaksi</h4>
              <div class="setting-row">
                <div class="setting-info"><div class="title">Sistem Peringatan Masuk</div><div class="desc">Kirim email otomatis berkala saat ada pesanan masuk</div></div>
                <div class="toggle on" onclick="this.classList.toggle('on')"></div>
              </div>
              <div class="setting-row">
                <div class="setting-info"><div class="title">Sistem Penilaian Bintang</div><div class="desc">Aktifkan modul rating dan komentar ulasan</div></div>
                <div class="toggle on" onclick="this.classList.toggle('on')"></div>
              </div>
            </div>
            <button class="tbl-btn success" style="padding:12px 24px; font-weight:700; border-radius:10px;" onclick="showToast('✅ Pengaturan sistem disimpan ke database!')">Simpan Aturan Baru</button>
          </div>
          
          <div class="card">
            <div class="card-header"><h3>ℹ️ Informasi Sistem</h3></div>
            <div style="font-size:0.875rem; color:var(--text-muted-dark); line-height:2.5;">
              <div style="display:flex; justify-content:space-between; border-bottom:1px solid #f1f5f9; padding-bottom:4px;"><span>Versi Kode Sistem</span><strong style="color:var(--text-dark)">v1.1.5 Stable Build</strong></div>
              <div style="display:flex; justify-content:space-between; border-bottom:1px solid #f1f5f9; padding-bottom:4px;"><span>Engine Core PHP</span><strong style="color:var(--text-dark)"><?= PHP_VERSION ?></strong></div>
              <div style="display:flex; justify-content:space-between; border-bottom:1px solid #f1f5f9; padding-bottom:4px;"><span>Tipe Driver DB</span><strong style="color:var(--text-dark)">MariaDB Client 10.4</strong></div>
              <div style="display:flex; justify-content:space-between; padding-bottom:4px;"><span>Status Ping Server</span><strong style="color:#10b981;">🟢 Active Running</strong></div>
            </div>
          </div>
        </div>
      </div>

    </div>
  </div>
</div>

<div class="modal-overlay" id="confirmModal" onclick="closeModal(event)">
  <div class="modal-box">
    <h3>⚠️ Konfirmasi Tindakan Permanen</h3>
    <p id="confirmMsg">Apakah Anda benar-benar yakin ingin mengeksekusi penghapusan data ini secara permanen?</p>
    <div class="modal-btns">
      <button class="btn-cancel" onclick="document.getElementById('confirmModal').classList.remove('show')">Batalkan</button>
      <a id="confirmBtn" href="#" class="btn-confirm" style="text-decoration:none;">Eksekusi Hapus</a>
    </div>
  </div>
</div>

<div class="toast" id="toast">🔔 <span id="toastMsg"></span></div>

<script>
  function showPanel(name, el) {
    document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
    document.getElementById('panel-' + name).classList.add('active');
    if (el) {
      document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
      el.classList.add('active');
    }
    const titles = {
      overview:    ['Admin Overview',        'Ringkasan aktivitas platform SkillCampus'],
      users:       ['Kelola Pengguna',        'Manajemen akun pengguna'],
      jasa:        ['Kelola Jasa',            'Semua jasa yang terdaftar di platform'],
      transaksi:   ['Transaksi',              'Riwayat semua pesanan'],
      laporan:     ['Laporan & Statistik',    'Analitik platform'],
      pengaturan:  ['Pengaturan Sistem',      'Konfigurasi platform']
    };
    if (titles[name]) {
      document.getElementById('topbarTitle').textContent = titles[name][0];
      document.getElementById('topbarSub').textContent   = titles[name][1];
    }
  }

  function searchTable(input, tableId) {
    const kw = input.value.toLowerCase();
    document.querySelectorAll('#' + tableId + ' tbody tr').forEach(row => {
      row.style.display = row.textContent.toLowerCase().includes(kw) ? '' : 'none';
    });
  }

  function filterTable(sel, tableId, colIdx) {
    const val = sel.value.toLowerCase();
    document.querySelectorAll('#' + tableId + ' tbody tr').forEach(row => {
      const cell = row.cells[colIdx];
      row.style.display = (!val || (cell && cell.textContent.toLowerCase().includes(val))) ? '' : 'none';
    });
  }

  function confirmHapus(url, nama) {
    document.getElementById('confirmMsg').textContent = 'Apakah Anda benar-benar yakin ingin menghapus data "' + nama + '"? Tindakan ini akan menghapusnya secara permanen dari server database.';
    document.getElementById('confirmBtn').href = url;
    document.getElementById('confirmModal').classList.add('show');
  }

  function closeModal(e) {
    if (e.target.id === 'confirmModal') document.getElementById('confirmModal').classList.remove('show');
  }

  let toastTimer;
  function showToast(msg) {
    const t = document.getElementById('toast');
    document.getElementById('toastMsg').textContent = msg;
    t.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => t.classList.remove('show'), 2800);
  }
</script>

<script>
(function(){
  const cv=document.getElementById('bg-canvas'),ctx=cv.getContext('2d');
  let W,H,pts=[];
  function resize(){W=cv.width=innerWidth;H=cv.height=innerHeight;pts=[];const n=Math.floor(W*H/14000);for(let i=0;i<n;i++)pts.push({x:Math.random()*W,y:Math.random()*H,vx:(Math.random()-.5)*0.3,vy:(Math.random()-.5)*0.3,r:Math.random()*1.5+0.5,a:Math.random()})}
  function draw(){
    ctx.clearRect(0,0,W,H);
    ctx.fillStyle='#050a18';ctx.fillRect(0,0,W,H);
    pts.forEach(p=>{
      p.x+=p.vx;p.y+=p.vy;
      if(p.x<0||p.x>W)p.vx*=-1;
      if(p.y<0||p.y>H)p.vy*=-1;
      ctx.beginPath();ctx.arc(p.x,p.y,p.r,0,Math.PI*2);
      ctx.fillStyle=`rgba(96,165,250,${p.a*0.5})`;ctx.fill();
    });
    for(let i=0;i<pts.length;i++)for(let j=i+1;j<pts.length;j++){
      const dx=pts[i].x-pts[j].x,dy=pts[i].y-pts[j].y,d=Math.sqrt(dx*dx+dy*dy);
      if(d<120){ctx.beginPath();ctx.moveTo(pts[i].x,pts[i].y);ctx.lineTo(pts[j].x,pts[j].y);ctx.strokeStyle=`rgba(96,165,250,${(1-d/120)*0.12})`;ctx.lineWidth=0.5;ctx.stroke()}
    }
    requestAnimationFrame(draw);
  }
  addEventListener('resize',resize);resize();draw();
})();
</script>
</body>
</html>
<?php mysqli_close($koneksi); ?>