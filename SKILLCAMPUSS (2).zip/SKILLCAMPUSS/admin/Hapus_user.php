<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../login.php'); 
    exit;
}

require_once '../config/koneksi.php';

$id = intval($_GET['id'] ?? 0);

if ($id > 0) {
    // Hapus ulasan milik user
    mysqli_query($koneksi, "DELETE FROM ulasan WHERE user_id = $id");
    // Hapus pesanan milik user sebagai pemesan
    mysqli_query($koneksi, "DELETE FROM pesanan WHERE user_id = $id");
    
    // Hapus pesanan & ulasan terkait jasa milik user ini sebelum menghapus jasanya
    $jasas = mysqli_query($koneksi, "SELECT id FROM jasa WHERE user_id = $id");
    while ($j = mysqli_fetch_assoc($jasas)) {
        mysqli_query($koneksi, "DELETE FROM ulasan WHERE jasa_id = {$j['id']}");
        mysqli_query($koneksi, "DELETE FROM pesanan WHERE jasa_id = {$j['id']}");
    }
    
    // Hapus seluruh portofolio jasa milik user
    mysqli_query($koneksi, "DELETE FROM jasa WHERE user_id = $id");
    // Eksekusi penghapusan akun (Proteksi: Tidak bisa menghapus sesama admin)
    mysqli_query($koneksi, "DELETE FROM users WHERE id = $id AND role != 'admin'");
}

mysqli_close($koneksi);
header('Location: dashboard.php');
exit;