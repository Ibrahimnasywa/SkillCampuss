<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../login.php'); 
    exit;
}

require_once '../config/koneksi.php';

$id = intval($_GET['id'] ?? 0);

if ($id > 0) {
    // Hapus ulasan & pesanan terkait dulu untuk mengamankan foreign key constraint
    mysqli_query($koneksi, "DELETE FROM ulasan WHERE jasa_id = $id");
    mysqli_query($koneksi, "DELETE FROM pesanan WHERE jasa_id = $id");
    // Baru hapus jasa dari katalog utama
    mysqli_query($koneksi, "DELETE FROM jasa WHERE id = $id");
}

mysqli_close($koneksi);
header('Location: dashboard.php');
exit;